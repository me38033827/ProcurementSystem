package com.ProcurementSystem.dao;

import com.ProcurementSystem.entity.Template;

public interface IBuyerTemplateDao {

	void add(Template template);//添加

}
