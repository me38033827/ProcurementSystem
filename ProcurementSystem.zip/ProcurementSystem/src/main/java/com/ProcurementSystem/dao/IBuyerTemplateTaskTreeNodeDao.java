package com.ProcurementSystem.dao;

import com.ProcurementSystem.entity.TemplateTaskTreeNode;

public interface IBuyerTemplateTaskTreeNodeDao {

	void add(TemplateTaskTreeNode templateTaskTreeNode);//添加

}
